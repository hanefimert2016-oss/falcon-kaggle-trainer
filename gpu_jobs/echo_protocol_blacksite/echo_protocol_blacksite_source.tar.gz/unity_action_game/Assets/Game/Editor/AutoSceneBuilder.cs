#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace EchoProtocol.Editor
{
    public static class AutoSceneBuilder
    {
        private const string ExternalRoot = "Assets/External";
        private const string ScenePath = "Assets/Game/Scenes/Blacksite.unity";

        [MenuItem("Echo Protocol/Build Blacksite Demo Scene")]
        public static void BuildAll()
        {
            if (!AssetDatabase.IsValidFolder(ExternalRoot))
                throw new InvalidOperationException("External assets are missing. Run tools/fetch_external_assets.sh first.");

            List<string> modelPaths = FindExternalModels();
            if (modelPaths.Count == 0)
                throw new InvalidOperationException("No external FBX/OBJ GameObjects were imported under Assets/External.");

            Directory.CreateDirectory("Assets/Game/Scenes");
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            CreateLighting();
            CreateGround();

            GameObject player = CreatePlayer(modelPaths);
            CreateCamera(player.transform);
            CreateEnvironment(modelPaths);

            GameObject manager = new GameObject("Game_Directors");
            manager.AddComponent<GameSession>();
            manager.AddComponent<StoryDirector>();
            MissionDirector mission = manager.AddComponent<MissionDirector>();
            manager.AddComponent<GameHUD>();

            CreateTowerZone();
            CreateArchiveTerminal(modelPaths);
            List<GameObject> enemies = CreateAmbushEnemies(modelPaths, 5);
            mission.ConfigureAmbush(enemies, enemies.Count);
            CreateExtractionZone();

            EditorSceneManager.MarkSceneDirty(scene);
            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            Selection.activeGameObject = player;
            Debug.Log($"Echo Protocol scene built with {modelPaths.Count} imported external model assets: {ScenePath}");
        }

        private static List<string> FindExternalModels()
        {
            return AssetDatabase.FindAssets("t:GameObject", new[] { ExternalRoot })
                .Select(AssetDatabase.GUIDToAssetPath)
                .Where(p => p.EndsWith(".fbx", StringComparison.OrdinalIgnoreCase) || p.EndsWith(".obj", StringComparison.OrdinalIgnoreCase) || p.EndsWith(".prefab", StringComparison.OrdinalIgnoreCase))
                .Distinct()
                .OrderBy(p => p)
                .ToList();
        }

        private static void CreateLighting()
        {
            GameObject lightObject = new GameObject("Moon_Key_Light");
            Light light = lightObject.AddComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 1.25f;
            light.shadows = LightShadows.Soft;
            lightObject.transform.rotation = Quaternion.Euler(42f, -35f, 0f);

            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(0.15f, 0.18f, 0.28f);
            RenderSettings.ambientEquatorColor = new Color(0.07f, 0.09f, 0.13f);
            RenderSettings.ambientGroundColor = new Color(0.03f, 0.035f, 0.05f);
            RenderSettings.fog = true;
            RenderSettings.fogColor = new Color(0.06f, 0.075f, 0.1f);
            RenderSettings.fogDensity = 0.012f;
        }

        private static void CreateGround()
        {
            GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
            ground.name = "Blacksite_Ground_Collider";
            ground.transform.position = new Vector3(0f, -0.5f, 12f);
            ground.transform.localScale = new Vector3(72f, 1f, 92f);
            Renderer renderer = ground.GetComponent<Renderer>();
            if (renderer != null)
            {
                Material mat = new Material(Shader.Find("Standard"));
                mat.color = new Color(0.09f, 0.1f, 0.12f);
                renderer.sharedMaterial = mat;
            }
        }

        private static GameObject CreatePlayer(List<string> paths)
        {
            GameObject player = new GameObject("Player_Agent");
            player.transform.position = new Vector3(0f, 0.05f, -22f);
            player.tag = "Player";
            player.layer = 2; // Ignore Raycast: prevents the camera/weapon ray from hitting the player controller.

            CharacterController cc = player.AddComponent<CharacterController>();
            cc.height = 1.8f;
            cc.radius = 0.34f;
            cc.center = new Vector3(0f, 0.9f, 0f);
            player.AddComponent<Health>();
            player.AddComponent<WeaponSystem>();
            player.AddComponent<PlayerController>();

            string model = PickModel(paths, new[] { "character", "player", "soldier", "human", "agent", "male", "female" }, new[] { "enemy", "robot", "turret", "weapon", "gun" });
            AddExternalVisual(player.transform, model, 1.75f, "Player_External_Visual");
            return player;
        }

        private static void CreateCamera(Transform target)
        {
            GameObject cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            Camera camera = cameraObject.AddComponent<Camera>();
            camera.fieldOfView = 68f;
            camera.nearClipPlane = 0.05f;
            cameraObject.AddComponent<AudioListener>();
            ThirdPersonCamera rig = cameraObject.AddComponent<ThirdPersonCamera>();
            rig.SetTarget(target);
            cameraObject.transform.position = target.position + new Vector3(0f, 2.3f, -5f);
        }

        private static void CreateEnvironment(List<string> paths)
        {
            GameObject root = new GameObject("External_Environment");
            string[] keywords = { "container", "crate", "barrel", "fence", "wall", "building", "tower", "rock", "prop", "street", "hazmat", "tank" };
            List<string> candidates = paths.Where(p => keywords.Any(k => p.IndexOf(k, StringComparison.OrdinalIgnoreCase) >= 0)).Take(40).ToList();
            if (candidates.Count == 0) candidates = paths.Take(20).ToList();

            Vector3[] anchors =
            {
                new Vector3(-14,0,-12), new Vector3(12,0,-10), new Vector3(-18,0,0), new Vector3(18,0,2),
                new Vector3(-22,0,16), new Vector3(22,0,18), new Vector3(-16,0,30), new Vector3(16,0,32),
                new Vector3(-7,0,5), new Vector3(8,0,8), new Vector3(-9,0,22), new Vector3(10,0,24),
                new Vector3(-26,0,38), new Vector3(26,0,40), new Vector3(-5,0,44), new Vector3(6,0,48)
            };

            for (int i = 0; i < anchors.Length; i++)
            {
                string path = candidates[i % candidates.Count];
                GameObject visual = InstantiateAsset(path, root.transform, $"Env_{i:00}");
                if (visual == null) continue;
                visual.transform.position = anchors[i];
                visual.transform.rotation = Quaternion.Euler(0f, (i * 47) % 360, 0f);
                FitVisual(visual, 2.5f + (i % 4) * 0.8f);
                EnsureStaticCollider(visual);
            }
        }

        private static void CreateTowerZone()
        {
            GameObject zone = new GameObject("Objective_Tower_Entry");
            zone.transform.position = new Vector3(0f, 1.5f, 10f);
            BoxCollider col = zone.AddComponent<BoxCollider>();
            col.isTrigger = true;
            col.size = new Vector3(12f, 3f, 6f);
            ObjectiveZone script = zone.AddComponent<ObjectiveZone>();
            script.Configure(ObjectiveZoneType.Tower);
        }

        private static void CreateArchiveTerminal(List<string> paths)
        {
            GameObject terminal = new GameObject("Archive_Terminal");
            terminal.transform.position = new Vector3(0f, 1f, 25f);
            terminal.AddComponent<ArchiveTerminal>();

            string model = PickModel(paths, new[] { "computer", "terminal", "screen", "crate", "container", "radio" }, Array.Empty<string>());
            AddExternalVisual(terminal.transform, model, 1.8f, "Terminal_External_Visual");

            BoxCollider collider = terminal.AddComponent<BoxCollider>();
            collider.size = new Vector3(2f, 2.2f, 1.5f);
            collider.center = new Vector3(0f, 0.7f, 0f);
        }

        private static List<GameObject> CreateAmbushEnemies(List<string> paths, int count)
        {
            List<GameObject> enemies = new List<GameObject>();
            string model = PickModel(paths, new[] { "enemy", "robot", "hazmat", "character", "soldier" }, new[] { "weapon", "gun" });
            Vector3[] positions =
            {
                new Vector3(-11,0,30), new Vector3(12,0,31), new Vector3(-17,0,21), new Vector3(17,0,20), new Vector3(0,0,38)
            };

            for (int i = 0; i < count; i++)
            {
                GameObject enemy = new GameObject($"Ambush_Enemy_{i + 1:00}");
                enemy.transform.position = positions[i % positions.Length];
                CharacterController cc = enemy.AddComponent<CharacterController>();
                cc.height = 1.8f;
                cc.radius = 0.35f;
                cc.center = new Vector3(0f, 0.9f, 0f);
                enemy.AddComponent<Health>();
                enemy.AddComponent<EnemyAI>();
                AddExternalVisual(enemy.transform, model, 1.72f, "Enemy_External_Visual");
                enemies.Add(enemy);
            }
            return enemies;
        }

        private static void CreateExtractionZone()
        {
            GameObject zone = new GameObject("Objective_Extraction");
            zone.transform.position = new Vector3(0f, 0.1f, 54f);
            BoxCollider col = zone.AddComponent<BoxCollider>();
            col.isTrigger = true;
            col.size = new Vector3(10f, 3f, 8f);
            ObjectiveZone script = zone.AddComponent<ObjectiveZone>();
            script.Configure(ObjectiveZoneType.Extraction);

            GameObject beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            beacon.name = "Extraction_Beacon";
            beacon.transform.SetParent(zone.transform, false);
            beacon.transform.localPosition = new Vector3(0f, 0.08f, 0f);
            beacon.transform.localScale = new Vector3(4f, 0.04f, 4f);
            Collider beaconCollider = beacon.GetComponent<Collider>();
            if (beaconCollider != null) UnityEngine.Object.DestroyImmediate(beaconCollider);
            Renderer renderer = beacon.GetComponent<Renderer>();
            if (renderer != null)
            {
                Material mat = new Material(Shader.Find("Standard"));
                mat.color = new Color(0.1f, 0.8f, 0.45f);
                renderer.sharedMaterial = mat;
            }
        }

        private static string PickModel(List<string> paths, IEnumerable<string> wanted, IEnumerable<string> excluded)
        {
            string best = null;
            int bestScore = int.MinValue;
            foreach (string path in paths)
            {
                int score = 0;
                foreach (string token in wanted)
                    if (path.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0) score += 10;
                foreach (string token in excluded)
                    if (path.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0) score -= 25;
                if (score > bestScore)
                {
                    best = path;
                    bestScore = score;
                }
            }
            return best ?? paths.FirstOrDefault();
        }

        private static GameObject AddExternalVisual(Transform parent, string assetPath, float targetHeight, string objectName)
        {
            GameObject visual = InstantiateAsset(assetPath, parent, objectName);
            if (visual == null) return null;
            visual.transform.localPosition = Vector3.zero;
            visual.transform.localRotation = Quaternion.identity;
            FitVisual(visual, targetHeight);
            visual.AddComponent<ExternalAssetMarker>();
            RemoveColliders(visual);
            return visual;
        }

        private static GameObject InstantiateAsset(string assetPath, Transform parent, string objectName)
        {
            if (string.IsNullOrEmpty(assetPath)) return null;
            GameObject asset = AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);
            if (asset == null) return null;
            GameObject instance = PrefabUtility.InstantiatePrefab(asset) as GameObject;
            if (instance == null) instance = UnityEngine.Object.Instantiate(asset);
            instance.name = objectName;
            instance.transform.SetParent(parent, true);
            return instance;
        }

        private static void FitVisual(GameObject root, float targetHeight)
        {
            Renderer[] renderers = root.GetComponentsInChildren<Renderer>(true);
            if (renderers.Length == 0) return;

            Bounds bounds = renderers[0].bounds;
            for (int i = 1; i < renderers.Length; i++) bounds.Encapsulate(renderers[i].bounds);
            float height = Mathf.Max(0.001f, bounds.size.y);
            float scale = Mathf.Clamp(targetHeight / height, 0.01f, 25f);
            root.transform.localScale *= scale;

            renderers = root.GetComponentsInChildren<Renderer>(true);
            bounds = renderers[0].bounds;
            for (int i = 1; i < renderers.Length; i++) bounds.Encapsulate(renderers[i].bounds);
            Vector3 correctionWorld = new Vector3(0f, -bounds.min.y, 0f);
            root.transform.position += correctionWorld;
        }

        private static void RemoveColliders(GameObject root)
        {
            foreach (Collider col in root.GetComponentsInChildren<Collider>(true))
                UnityEngine.Object.DestroyImmediate(col);
        }

        private static void EnsureStaticCollider(GameObject root)
        {
            foreach (Transform t in root.GetComponentsInChildren<Transform>(true)) t.gameObject.isStatic = true;
            if (root.GetComponentInChildren<Collider>() != null) return;
            BoxCollider col = root.AddComponent<BoxCollider>();
            Renderer[] renderers = root.GetComponentsInChildren<Renderer>();
            if (renderers.Length == 0) return;
            Bounds b = renderers[0].bounds;
            for (int i = 1; i < renderers.Length; i++) b.Encapsulate(renderers[i].bounds);
            col.center = root.transform.InverseTransformPoint(b.center);
            Vector3 localSize = root.transform.InverseTransformVector(b.size);
            col.size = new Vector3(Mathf.Abs(localSize.x), Mathf.Abs(localSize.y), Mathf.Abs(localSize.z));
        }
    }
}
#endif
