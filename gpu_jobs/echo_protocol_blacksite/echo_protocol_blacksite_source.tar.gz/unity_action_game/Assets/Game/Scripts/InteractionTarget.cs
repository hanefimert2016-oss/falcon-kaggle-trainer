using UnityEngine;

namespace EchoProtocol
{
    public abstract class InteractionTarget : MonoBehaviour
    {
        [SerializeField] private string prompt = "E - Etkileş";
        public string Prompt => prompt;
        public abstract bool CanInteract(PlayerController player);
        public abstract void Interact(PlayerController player);
    }
}
