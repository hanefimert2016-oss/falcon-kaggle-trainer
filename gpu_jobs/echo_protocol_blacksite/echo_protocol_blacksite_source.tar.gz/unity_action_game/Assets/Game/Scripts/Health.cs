using System;
using UnityEngine;

namespace EchoProtocol
{
    public sealed class Health : MonoBehaviour
    {
        [SerializeField] private float maxHealth = 100f;
        [SerializeField] private bool destroyOnDeath = true;

        public event Action<Health> Died;
        public event Action<float, float> Changed;

        public float Current { get; private set; }
        public float Max => maxHealth;
        public bool IsDead { get; private set; }

        private void Awake()
        {
            Current = maxHealth;
        }

        public void TakeDamage(float amount)
        {
            if (IsDead || amount <= 0f) return;
            Current = Mathf.Max(0f, Current - amount);
            Changed?.Invoke(Current, maxHealth);
            if (Current <= 0f) Die();
        }

        public void Heal(float amount)
        {
            if (IsDead || amount <= 0f) return;
            Current = Mathf.Min(maxHealth, Current + amount);
            Changed?.Invoke(Current, maxHealth);
        }

        private void Die()
        {
            if (IsDead) return;
            IsDead = true;
            Died?.Invoke(this);
            if (CompareTag("Player"))
            {
                GameSession.Instance?.FailMission("Ajan etkisiz hale getirildi.");
                return;
            }

            if (destroyOnDeath)
                Destroy(gameObject, 1.25f);
        }
    }
}
