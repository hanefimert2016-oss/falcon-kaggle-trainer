using UnityEngine;

namespace EchoProtocol
{
    public enum ObjectiveZoneType { Tower, Extraction }

    [RequireComponent(typeof(Collider))]
    public sealed class ObjectiveZone : MonoBehaviour
    {
        [SerializeField] private ObjectiveZoneType type;
        private bool used;

        public void Configure(ObjectiveZoneType zoneType) => type = zoneType;

        private void OnTriggerEnter(Collider other)
        {
            if (used || !other.CompareTag("Player")) return;
            if (type == ObjectiveZoneType.Tower)
            {
                MissionDirector.Instance?.ReachTower();
                used = true;
            }
            else if (type == ObjectiveZoneType.Extraction && MissionDirector.Instance != null && MissionDirector.Instance.Phase == MissionPhase.Extraction)
            {
                MissionDirector.Instance.ReachExtraction();
                used = true;
            }
        }
    }
}
