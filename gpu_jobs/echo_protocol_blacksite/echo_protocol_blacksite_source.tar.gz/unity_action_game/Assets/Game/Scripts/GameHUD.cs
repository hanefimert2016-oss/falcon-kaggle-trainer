using UnityEngine;

namespace EchoProtocol
{
    public sealed class GameHUD : MonoBehaviour
    {
        private GUIStyle title;
        private GUIStyle body;
        private GUIStyle center;
        private GUIStyle story;

        private void EnsureStyles()
        {
            if (title != null) return;
            title = new GUIStyle(GUI.skin.label) { fontSize = 18, fontStyle = FontStyle.Bold, normal = { textColor = Color.white } };
            body = new GUIStyle(GUI.skin.label) { fontSize = 15, normal = { textColor = Color.white } };
            center = new GUIStyle(body) { alignment = TextAnchor.MiddleCenter, fontSize = 22, fontStyle = FontStyle.Bold };
            story = new GUIStyle(body) { alignment = TextAnchor.MiddleCenter, fontSize = 17, wordWrap = true };
        }

        private void OnGUI()
        {
            EnsureStyles();
            PlayerController player = FindObjectOfType<PlayerController>();
            MissionDirector mission = MissionDirector.Instance;

            GUI.Box(new Rect(20, 20, 440, 92), GUIContent.none);
            GUI.Label(new Rect(34, 30, 400, 24), "ECHO PROTOCOL: BLACKSITE", title);
            GUI.Label(new Rect(34, 58, 400, 46), mission != null ? mission.ObjectiveText : "Görev yükleniyor...", body);

            if (player != null)
            {
                Health h = player.Health;
                WeaponSystem w = player.Weapon;
                GUI.Box(new Rect(Screen.width - 250, 20, 230, 92), GUIContent.none);
                GUI.Label(new Rect(Screen.width - 235, 32, 210, 25), $"CAN  {Mathf.CeilToInt(h.Current)}/{Mathf.CeilToInt(h.Max)}", body);
                GUI.Label(new Rect(Screen.width - 235, 62, 210, 25), w.IsReloading ? "ŞARJÖR  YÜKLENİYOR" : $"MERMİ  {w.Magazine}/{w.Reserve}", body);

                if (!string.IsNullOrEmpty(player.InteractionPrompt))
                    GUI.Label(new Rect(Screen.width * 0.5f - 180, Screen.height * 0.64f, 360, 40), player.InteractionPrompt, center);
            }

            GUI.Label(new Rect(Screen.width * 0.5f - 15, Screen.height * 0.5f - 18, 30, 36), "+", center);

            StoryDirector sd = StoryDirector.Instance;
            if (sd != null && sd.Visible)
            {
                GUI.Box(new Rect(Screen.width * 0.5f - 390, Screen.height - 150, 780, 95), GUIContent.none);
                GUI.Label(new Rect(Screen.width * 0.5f - 370, Screen.height - 138, 740, 26), sd.Speaker, title);
                GUI.Label(new Rect(Screen.width * 0.5f - 370, Screen.height - 110, 740, 48), sd.Line, story);
            }

            GameSession session = GameSession.Instance;
            if (session != null && !session.CanPlay)
            {
                GUI.Box(new Rect(Screen.width * 0.5f - 310, Screen.height * 0.5f - 80, 620, 160), GUIContent.none);
                GUI.Label(new Rect(Screen.width * 0.5f - 290, Screen.height * 0.5f - 30, 580, 60), session.EndMessage, center);
            }
        }
    }
}
