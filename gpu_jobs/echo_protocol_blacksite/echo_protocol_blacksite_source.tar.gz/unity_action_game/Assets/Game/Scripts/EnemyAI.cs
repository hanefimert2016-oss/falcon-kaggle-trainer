using UnityEngine;

namespace EchoProtocol
{
    [RequireComponent(typeof(CharacterController), typeof(Health))]
    public sealed class EnemyAI : MonoBehaviour
    {
        [SerializeField] private float moveSpeed = 3.4f;
        [SerializeField] private float detectionRange = 28f;
        [SerializeField] private float attackRange = 2.2f;
        [SerializeField] private float attackDamage = 16f;
        [SerializeField] private float attackCooldown = 1.0f;
        [SerializeField] private float gravity = -24f;

        private CharacterController controller;
        private Health health;
        private Transform target;
        private float nextAttack;
        private float verticalVelocity;

        private void Awake()
        {
            controller = GetComponent<CharacterController>();
            health = GetComponent<Health>();
            health.Died += OnDied;
        }

        private void OnDestroy()
        {
            if (health != null) health.Died -= OnDied;
        }

        private void Start()
        {
            PlayerController player = FindObjectOfType<PlayerController>();
            if (player != null) target = player.transform;
        }

        private void Update()
        {
            if (health.IsDead || target == null) return;
            if (GameSession.Instance != null && !GameSession.Instance.CanPlay) return;

            Vector3 toTarget = target.position - transform.position;
            Vector3 planar = Vector3.ProjectOnPlane(toTarget, Vector3.up);
            float distance = planar.magnitude;
            if (distance > detectionRange) return;

            if (distance > attackRange)
            {
                Vector3 direction = planar.normalized;
                controller.Move(direction * moveSpeed * Time.deltaTime);
                if (direction.sqrMagnitude > 0.01f)
                    transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(direction), 10f * Time.deltaTime);
            }
            else if (Time.time >= nextAttack)
            {
                nextAttack = Time.time + attackCooldown;
                Health playerHealth = target.GetComponent<Health>();
                if (playerHealth != null) playerHealth.TakeDamage(attackDamage);
            }

            if (controller.isGrounded && verticalVelocity < 0f) verticalVelocity = -2f;
            verticalVelocity += gravity * Time.deltaTime;
            controller.Move(Vector3.up * verticalVelocity * Time.deltaTime);
        }

        private void OnDied(Health dead)
        {
            MissionDirector.Instance?.RegisterEnemyKill();
            enabled = false;
            controller.enabled = false;
        }
    }
}
