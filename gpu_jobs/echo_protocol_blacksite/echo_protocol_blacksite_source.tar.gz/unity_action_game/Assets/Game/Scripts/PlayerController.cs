using UnityEngine;

namespace EchoProtocol
{
    [RequireComponent(typeof(CharacterController), typeof(Health), typeof(WeaponSystem))]
    public sealed class PlayerController : MonoBehaviour
    {
        [Header("Movement")]
        [SerializeField] private float walkSpeed = 5.2f;
        [SerializeField] private float sprintSpeed = 8.2f;
        [SerializeField] private float jumpHeight = 1.4f;
        [SerializeField] private float gravity = -24f;
        [SerializeField] private float rotationSharpness = 14f;
        [SerializeField] private float interactionDistance = 3.2f;

        private CharacterController controller;
        private Health health;
        private WeaponSystem weapon;
        private float verticalVelocity;
        private Camera viewCamera;

        public Health Health => health;
        public WeaponSystem Weapon => weapon;
        public string InteractionPrompt { get; private set; }

        private void Awake()
        {
            controller = GetComponent<CharacterController>();
            health = GetComponent<Health>();
            weapon = GetComponent<WeaponSystem>();
            gameObject.tag = "Player";
        }

        private void Start()
        {
            viewCamera = Camera.main;
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }

        private void Update()
        {
            if (health.IsDead) return;
            if (GameSession.Instance != null && !GameSession.Instance.CanPlay) return;

            Move();
            HandleInteraction();
            weapon.TickInput();

            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
        }

        private void Move()
        {
            if (viewCamera == null) viewCamera = Camera.main;
            Vector2 input = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
            input = Vector2.ClampMagnitude(input, 1f);

            Vector3 forward = viewCamera != null ? viewCamera.transform.forward : Vector3.forward;
            Vector3 right = viewCamera != null ? viewCamera.transform.right : Vector3.right;
            forward.y = 0f;
            right.y = 0f;
            forward.Normalize();
            right.Normalize();

            Vector3 move = (forward * input.y + right * input.x);
            float speed = Input.GetKey(KeyCode.LeftShift) ? sprintSpeed : walkSpeed;

            if (controller.isGrounded && verticalVelocity < 0f) verticalVelocity = -2f;
            if (controller.isGrounded && Input.GetButtonDown("Jump"))
                verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);
            verticalVelocity += gravity * Time.deltaTime;

            Vector3 velocity = move * speed;
            velocity.y = verticalVelocity;
            controller.Move(velocity * Time.deltaTime);

            if (move.sqrMagnitude > 0.04f)
            {
                Quaternion target = Quaternion.LookRotation(move, Vector3.up);
                transform.rotation = Quaternion.Slerp(transform.rotation, target, 1f - Mathf.Exp(-rotationSharpness * Time.deltaTime));
            }
        }

        private void HandleInteraction()
        {
            InteractionPrompt = string.Empty;
            if (viewCamera == null) return;

            Ray ray = new Ray(viewCamera.transform.position, viewCamera.transform.forward);
            if (!Physics.Raycast(ray, out RaycastHit hit, interactionDistance, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Collide)) return;

            InteractionTarget target = hit.collider.GetComponentInParent<InteractionTarget>();
            if (target == null || !target.CanInteract(this)) return;

            InteractionPrompt = target.Prompt;
            if (Input.GetKeyDown(KeyCode.E)) target.Interact(this);
        }
    }
}
