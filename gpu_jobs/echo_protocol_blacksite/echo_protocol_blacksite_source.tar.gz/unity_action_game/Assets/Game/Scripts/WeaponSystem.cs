using System.Collections;
using UnityEngine;

namespace EchoProtocol
{
    public sealed class WeaponSystem : MonoBehaviour
    {
        [Header("Weapon")]
        [SerializeField] private float damage = 34f;
        [SerializeField] private float range = 90f;
        [SerializeField] private float fireRate = 7f;
        [SerializeField] private int magazineSize = 18;
        [SerializeField] private int reserveAmmo = 90;
        [SerializeField] private float reloadSeconds = 1.35f;
        [SerializeField] private LayerMask hitMask = ~(1 << 2);

        private float nextFireTime;
        private bool reloading;
        private Camera aimCamera;

        public int Magazine { get; private set; }
        public int Reserve => reserveAmmo;
        public bool IsReloading => reloading;

        private void Awake()
        {
            Magazine = magazineSize;
        }

        private void Start()
        {
            aimCamera = Camera.main;
        }

        public void TickInput()
        {
            if (GameSession.Instance != null && !GameSession.Instance.CanPlay) return;
            if (Input.GetKeyDown(KeyCode.R)) TryReload();
            if (Input.GetMouseButton(0)) TryFire();
        }

        public void TryFire()
        {
            if (reloading || Time.time < nextFireTime) return;
            if (Magazine <= 0)
            {
                TryReload();
                return;
            }

            nextFireTime = Time.time + (1f / fireRate);
            Magazine--;
            if (aimCamera == null) aimCamera = Camera.main;
            if (aimCamera == null) return;

            Ray ray = new Ray(aimCamera.transform.position, aimCamera.transform.forward);
            if (Physics.Raycast(ray, out RaycastHit hit, range, hitMask, QueryTriggerInteraction.Ignore))
            {
                Health health = hit.collider.GetComponentInParent<Health>();
                if (health != null && !health.CompareTag("Player"))
                    health.TakeDamage(damage);

                Debug.DrawLine(ray.origin, hit.point, Color.red, 0.15f);
            }
            else
            {
                Debug.DrawRay(ray.origin, ray.direction * range, Color.red, 0.15f);
            }
        }

        public void TryReload()
        {
            if (reloading || Magazine >= magazineSize || reserveAmmo <= 0) return;
            StartCoroutine(ReloadRoutine());
        }

        private IEnumerator ReloadRoutine()
        {
            reloading = true;
            yield return new WaitForSeconds(reloadSeconds);
            int missing = magazineSize - Magazine;
            int moved = Mathf.Min(missing, reserveAmmo);
            Magazine += moved;
            reserveAmmo -= moved;
            reloading = false;
        }
    }
}
