using UnityEngine;

namespace EchoProtocol
{
    public sealed class ExternalAssetMarker : MonoBehaviour
    {
        [TextArea] public string source = "Quaternius - Toon Shooter Game Kit (CC0)";
    }
}
