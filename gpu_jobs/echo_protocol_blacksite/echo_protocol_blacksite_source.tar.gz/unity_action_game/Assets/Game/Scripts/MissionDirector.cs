using System.Collections.Generic;
using UnityEngine;

namespace EchoProtocol
{
    public enum MissionPhase
    {
        Infiltrate,
        RetrieveArchive,
        SurviveAmbush,
        Extraction,
        Complete
    }

    public sealed class MissionDirector : MonoBehaviour
    {
        public static MissionDirector Instance { get; private set; }

        [SerializeField] private List<GameObject> ambushEnemies = new List<GameObject>();
        [SerializeField] private int requiredKills = 5;

        public MissionPhase Phase { get; private set; } = MissionPhase.Infiltrate;
        public int Kills { get; private set; }
        public string ObjectiveText { get; private set; }

        private void Awake()
        {
            Instance = this;
            foreach (GameObject enemy in ambushEnemies)
                if (enemy != null) enemy.SetActive(false);
        }

        private void Start()
        {
            SetObjective("İletişim kulesine sız.");
            StoryDirector.Instance?.Say("ECHO", "Blacksite çevrimdışı görünüyor. İçeri gir ve arşivi bul.", 5f);
        }

        public void ConfigureAmbush(List<GameObject> enemies, int killsNeeded)
        {
            ambushEnemies = enemies ?? new List<GameObject>();
            requiredKills = Mathf.Max(1, killsNeeded);
        }

        public void ReachTower()
        {
            if (Phase != MissionPhase.Infiltrate) return;
            Phase = MissionPhase.RetrieveArchive;
            SetObjective("Şifreli arşiv terminalini bul ve E ile indir.");
            StoryDirector.Instance?.Say("ECHO", "İçeridesin. Terminalin yerini işaretliyorum.", 4f);
        }

        public void RetrieveArchive()
        {
            if (Phase != MissionPhase.RetrieveArchive) return;
            Phase = MissionPhase.SurviveAmbush;
            Kills = 0;
            SetObjective($"Pusuyu temizle: {Kills}/{requiredKills}");
            foreach (GameObject enemy in ambushEnemies)
                if (enemy != null) enemy.SetActive(true);
            StoryDirector.Instance?.Say("KONTROL", "Alarm tetiklendi. Temas! Alanı temizle!", 4f);
        }

        public void RegisterEnemyKill()
        {
            if (Phase != MissionPhase.SurviveAmbush) return;
            Kills++;
            SetObjective($"Pusuyu temizle: {Kills}/{requiredKills}");
            if (Kills < requiredKills) return;

            Phase = MissionPhase.Extraction;
            SetObjective("Tahliye bölgesine ulaş.");
            StoryDirector.Instance?.Say("ECHO", "Arşiv güvenli. Güney tahliyesine koş.", 4f);
        }

        public void ReachExtraction()
        {
            if (Phase != MissionPhase.Extraction) return;
            Phase = MissionPhase.Complete;
            SetObjective("GÖREV TAMAMLANDI");
            StoryDirector.Instance?.Say("KONTROL", "Paket alındı. Blacksite artık kör değil.", 6f);
            GameSession.Instance?.CompleteMission();
        }

        private void SetObjective(string text)
        {
            ObjectiveText = text;
        }
    }
}
