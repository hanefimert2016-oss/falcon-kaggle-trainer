using UnityEngine;

namespace EchoProtocol
{
    public sealed class GameSession : MonoBehaviour
    {
        public static GameSession Instance { get; private set; }
        public bool CanPlay { get; private set; } = true;
        public bool MissionComplete { get; private set; }
        public string EndMessage { get; private set; }

        private void Awake()
        {
            Instance = this;
            Time.timeScale = 1f;
        }

        public void CompleteMission()
        {
            MissionComplete = true;
            EndMessage = "ECHO PROTOCOL // GÖREV TAMAMLANDI";
            CanPlay = false;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }

        public void FailMission(string reason)
        {
            MissionComplete = false;
            EndMessage = reason;
            CanPlay = false;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
    }
}
