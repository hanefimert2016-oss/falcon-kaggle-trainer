using System.Collections;
using UnityEngine;

namespace EchoProtocol
{
    public sealed class StoryDirector : MonoBehaviour
    {
        public static StoryDirector Instance { get; private set; }
        public string Speaker { get; private set; }
        public string Line { get; private set; }
        public bool Visible { get; private set; }

        private Coroutine active;

        private void Awake()
        {
            Instance = this;
        }

        public void Say(string speaker, string line, float duration)
        {
            if (active != null) StopCoroutine(active);
            active = StartCoroutine(LineRoutine(speaker, line, duration));
        }

        private IEnumerator LineRoutine(string speaker, string line, float duration)
        {
            Speaker = speaker;
            Line = line;
            Visible = true;
            yield return new WaitForSecondsRealtime(Mathf.Max(1f, duration));
            Visible = false;
            active = null;
        }
    }
}
