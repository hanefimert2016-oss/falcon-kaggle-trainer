using UnityEngine;

namespace EchoProtocol
{
    public sealed class ThirdPersonCamera : MonoBehaviour
    {
        [SerializeField] private Transform target;
        [SerializeField] private Vector3 pivotOffset = new Vector3(0f, 1.6f, 0f);
        [SerializeField] private float distance = 5.2f;
        [SerializeField] private float mouseSensitivity = 2.6f;
        [SerializeField] private float minPitch = -35f;
        [SerializeField] private float maxPitch = 70f;
        [SerializeField] private float smooth = 18f;
        [SerializeField] private LayerMask collisionMask = ~(1 << 2);

        private float yaw;
        private float pitch = 12f;

        public void SetTarget(Transform value) => target = value;

        private void LateUpdate()
        {
            if (target == null) return;

            yaw += Input.GetAxis("Mouse X") * mouseSensitivity;
            pitch -= Input.GetAxis("Mouse Y") * mouseSensitivity;
            pitch = Mathf.Clamp(pitch, minPitch, maxPitch);

            Quaternion rotation = Quaternion.Euler(pitch, yaw, 0f);
            Vector3 pivot = target.position + pivotOffset;
            Vector3 desired = pivot - rotation * Vector3.forward * distance;

            Vector3 direction = desired - pivot;
            float wantedDistance = direction.magnitude;
            if (Physics.SphereCast(pivot, 0.18f, direction.normalized, out RaycastHit hit, wantedDistance, collisionMask, QueryTriggerInteraction.Ignore))
                desired = pivot + direction.normalized * Mathf.Max(0.45f, hit.distance - 0.2f);

            float t = 1f - Mathf.Exp(-smooth * Time.deltaTime);
            transform.position = Vector3.Lerp(transform.position, desired, t);
            transform.rotation = Quaternion.Slerp(transform.rotation, rotation, t);
        }
    }
}
