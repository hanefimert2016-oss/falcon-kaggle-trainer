using UnityEngine;

namespace EchoProtocol
{
    public sealed class ArchiveTerminal : InteractionTarget
    {
        private bool used;

        public override bool CanInteract(PlayerController player)
        {
            return !used && MissionDirector.Instance != null && MissionDirector.Instance.Phase == MissionPhase.RetrieveArchive;
        }

        public override void Interact(PlayerController player)
        {
            if (!CanInteract(player)) return;
            used = true;
            MissionDirector.Instance.RetrieveArchive();
        }
    }
}
