#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CACHE="$ROOT/.asset-cache"
STAGE="$CACHE/stage"
DEST="$ROOT/Assets/External/Quaternius_SciFiEssentials"
MODELS_URL="https://opengameart.org/sites/default/files/sci-fi_essentials_kit_models.zip"
TEXTURES_URL="https://opengameart.org/sites/default/files/sci-fi_essentials_kit_textures.zip"

mkdir -p "$CACHE" "$STAGE" "$DEST"

download() {
  local url="$1" out="$2"
  if [[ ! -s "$out" ]]; then
    echo "Downloading $url"
    curl --fail --location --retry 4 --retry-delay 3 --user-agent "Mozilla/5.0 EchoProtocolCI" -o "$out" "$url"
  fi
}

download "$MODELS_URL" "$CACHE/models.zip"
download "$TEXTURES_URL" "$CACHE/textures.zip"

rm -rf "$STAGE" "$DEST"
mkdir -p "$STAGE" "$DEST"
unzip -q -o "$CACHE/models.zip" -d "$STAGE"
unzip -q -o "$CACHE/textures.zip" -d "$STAGE"

copied=0
while IFS= read -r -d '' file; do
  rel="${file#"$STAGE"/}"
  mkdir -p "$DEST/$(dirname "$rel")"
  cp -f "$file" "$DEST/$rel"
  copied=$((copied + 1))
done < <(find "$STAGE" -type f \( \
  -iname '*.fbx' -o -iname '*.obj' -o -iname '*.mtl' -o \
  -iname '*.png' -o -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.tga' \
\) -print0)

models=$(find "$DEST" -type f \( -iname '*.fbx' -o -iname '*.obj' \) | wc -l | tr -d ' ')
textures=$(find "$DEST" -type f \( -iname '*.png' -o -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.tga' \) | wc -l | tr -d ' ')

cat > "$ROOT/Assets/External/ASSET_SOURCE.txt" <<TXT
Echo Protocol external 3D source
Creator: Quaternius
Pack: Sci-Fi Essentials Kit (Standard)
License: CC0 1.0 Universal
Source page: https://opengameart.org/content/sci-fi-essentials-kit
Original site: https://quaternius.com/packs/scifiessentialskit.html
Downloaded models archive: $MODELS_URL
Downloaded textures archive: $TEXTURES_URL
Models detected: $models
Textures detected: $textures
TXT

if [[ "$models" -lt 5 ]]; then
  echo "ERROR: expected at least 5 external 3D model files, found $models" >&2
  exit 4
fi

printf 'External asset fetch complete: copied=%s models=%s textures=%s\n' "$copied" "$models" "$textures"
