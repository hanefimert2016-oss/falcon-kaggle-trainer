#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "Assets" / "Game" / "Scripts"
EXTERNAL = ROOT / "Assets" / "External"

required = [
    "PlayerController.cs",
    "ThirdPersonCamera.cs",
    "WeaponSystem.cs",
    "Health.cs",
    "EnemyAI.cs",
    "MissionDirector.cs",
    "StoryDirector.cs",
    "ObjectiveZone.cs",
    "ArchiveTerminal.cs",
    "GameHUD.cs",
    "GameSession.cs",
]

errors: list[str] = []
for name in required:
    if not (SCRIPTS / name).is_file():
        errors.append(f"missing C# file: {name}")

mission_text = (SCRIPTS / "MissionDirector.cs").read_text(encoding="utf-8") if (SCRIPTS / "MissionDirector.cs").exists() else ""
for phase in ("Infiltrate", "RetrieveArchive", "SurviveAmbush", "Extraction", "Complete"):
    if phase not in mission_text:
        errors.append(f"mission phase missing: {phase}")

player_text = (SCRIPTS / "PlayerController.cs").read_text(encoding="utf-8") if (SCRIPTS / "PlayerController.cs").exists() else ""
for control in ("Horizontal", "Vertical", "LeftShift", "Jump", "KeyCode.E"):
    if control not in player_text:
        errors.append(f"player control token missing: {control}")

weapon_text = (SCRIPTS / "WeaponSystem.cs").read_text(encoding="utf-8") if (SCRIPTS / "WeaponSystem.cs").exists() else ""
for token in ("GetMouseButton(0)", "KeyCode.R", "Physics.Raycast", "TakeDamage"):
    if token not in weapon_text:
        errors.append(f"weapon behavior token missing: {token}")

# Lightweight structural sanity check for accidental truncation.
for cs in sorted(SCRIPTS.glob("*.cs")):
    text = re.sub(r'//.*', '', cs.read_text(encoding="utf-8"))
    if text.count("{") != text.count("}"):
        errors.append(f"brace mismatch: {cs.name}")
    if "namespace EchoProtocol" not in text:
        errors.append(f"namespace missing: {cs.name}")

models = []
textures = []
if EXTERNAL.exists():
    models = [p for p in EXTERNAL.rglob("*") if p.suffix.lower() in {".fbx", ".obj"}]
    textures = [p for p in EXTERNAL.rglob("*") if p.suffix.lower() in {".png", ".jpg", ".jpeg", ".tga"}]
else:
    errors.append("Assets/External was not produced by the fetch step")

if len(models) < 5:
    errors.append(f"too few external models: {len(models)}")
if not (EXTERNAL / "ASSET_SOURCE.txt").exists():
    errors.append("asset attribution/source record missing")

# Enforce the user's constraint: authored source tree must not contain hand-made model files.
tracked_model_dir = ROOT / "Assets" / "Game"
handmade = [p for p in tracked_model_dir.rglob("*") if p.suffix.lower() in {".fbx", ".obj", ".blend", ".gltf", ".glb"}]
if handmade:
    errors.append("unexpected authored 3D model files under Assets/Game: " + ", ".join(map(str, handmade[:5])))

report = {
    "game": "Echo Protocol: Blacksite",
    "validation": "failed" if errors else "passed",
    "csharp_files": len(list(SCRIPTS.glob("*.cs"))),
    "external_models": len(models),
    "external_textures": len(textures),
    "external_source": "Quaternius Sci-Fi Essentials Kit / CC0",
    "errors": errors,
}
(ROOT / "build_report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2, ensure_ascii=False))
if errors:
    sys.exit(1)
