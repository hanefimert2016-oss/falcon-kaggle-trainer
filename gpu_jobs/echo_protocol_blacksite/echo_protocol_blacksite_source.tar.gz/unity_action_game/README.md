# Echo Protocol: Blacksite

A compact third-person action-story prototype for Unity. The gameplay code and scene assembly are authored in this repository, while the visible 3D models/textures are downloaded from an external CC0 asset pack instead of being generated here.

## Story

You control ECHO-7, an operative sent into a dark communications blacksite. Enter the facility, recover the encrypted archive, survive the security ambush, then reach extraction.

Mission flow:

1. Infiltrate the communications tower.
2. Find the archive terminal and press **E**.
3. Defeat the five activated enemies.
4. Reach the extraction zone.

## Controls

- **WASD** — move
- **Mouse** — camera / aim
- **Left Shift** — sprint
- **Space** — jump
- **Left Mouse** — fire
- **R** — reload
- **E** — interact
- **Esc** — release mouse cursor

## External 3D assets

Visible models and textures come from **Quaternius — Sci-Fi Essentials Kit (Standard)**, mirrored by OpenGameArt under **CC0 1.0**. The pack includes sci-fi props, guns and animated robot enemies. No custom FBX/OBJ/Blend models are authored by this project.

- Source page: https://opengameart.org/content/sci-fi-essentials-kit
- Creator page: https://quaternius.com/packs/scifiessentialskit.html

Fetch them with:

```bash
cd unity_action_game
./tools/fetch_external_assets.sh
```

The downloaded assets are intentionally gitignored and are recreated by GitHub Actions.

## Build the demo scene in Unity

1. Install/open with Unity **2022.3 LTS** (project marker: 2022.3.62f3).
2. Run `./tools/fetch_external_assets.sh` before opening, or fetch the assets from the same URLs manually.
3. Open the project.
4. From the Unity menu choose **Echo Protocol → Build Blacksite Demo Scene**.
5. Open `Assets/Game/Scenes/Blacksite.unity` and press Play.

`AutoSceneBuilder` searches the imported external FBX/OBJ files and automatically picks character/enemy/terminal/environment visuals, then creates the mission triggers and five-enemy ambush.

## GitHub CPU job

`.github/workflows/unity-action-story-cpu.yml` runs on Ubuntu CPU. It downloads the external CC0 model/texture archives, validates the Unity source/mission flow, counts the imported model files, writes `build_report.json`, and uploads a ready-to-open Unity project artifact containing the downloaded assets.

A headless Unity player build is not forced in CI because Unity Editor activation requires a Unity license/activation secret. The CPU job still verifies the asset pipeline and project structure without needing a GPU.
