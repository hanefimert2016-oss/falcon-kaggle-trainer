# Echo Protocol: Blacksite — Godot 4

Bu proje, aynı oynanış akışını koruyacak şekilde Unity sürümünden **Godot 4 + GDScript** projesine çevrildi.

## Korunan sistemler
- Üçüncü şahıs WASD hareketi, Shift koşma, Space zıplama
- Mouse kamera + SpringArm3D duvar çarpışması
- Sol tık ateş, R şarjör değiştirme
- Can sistemi ve oyuncu ölümü
- Yakın dövüş saldırısı yapan takipçi düşman AI
- E ile arşiv terminali etkileşimi
- Görev akışı: kuleye sız → arşivi indir → 5 düşmanı temizle → tahliye
- HUD, görev yazısı, mermi/can, diyalog ve görev sonu ekranı

## 3D asset politikası
Yeni karakter, silah veya düşman modeli üretilmedi. Godot sürümü Unity artifact'ında bulunan ve daha önce dışarıdan indirilmiş **Quaternius CC0** paketlerinin OBJ/MTL sürümlerini kullanıyor:
- Animated Characters Pack → `Soldier_Male.obj` oyuncu
- Sci-Fi Essentials Kit → EyeDrone / QuadShell / Trilobite, rifle ve prop'lar

Godot dönüştürmesinde toplam **89 harici OBJ modeli** bulunur. Görünür sahne modelleri bu paketlerden seçilir. Basit BoxMesh/CylinderMesh öğeleri yalnızca fiziksel zemin/duvar ve hedef işaretleyicileridir; karakter/silah/düşman modeli değildir.

## Açma
1. Godot 4.x aç.
2. `project.godot` dosyasını Import/Open Project ile seç.
3. İlk asset importunun bitmesini bekle.
4. F6/F5 ile çalıştır.

## Kontroller
- `WASD`: hareket
- `Left Shift`: koş
- `Space`: zıpla
- `Mouse`: kamera
- `Sol tık`: ateş
- `R`: şarjör değiştir
- `E`: etkileşim
- `Esc`: mouse'u serbest bırak
- `Sağ tık`: mouse'u tekrar yakala

## Godot eşleştirmeleri
Unity `CharacterController` → Godot `CharacterBody3D`  
Unity `Physics.Raycast` → `PhysicsDirectSpaceState3D.intersect_ray`  
Unity trigger collider → `Area3D`  
Unity Camera rig → `SpringArm3D + Camera3D`  
Unity OnGUI → `CanvasLayer/Control`  
Unity C# gameplay → GDScript

Dış asset lisans bilgisi: `assets/external/ASSET_SOURCE.txt`.
