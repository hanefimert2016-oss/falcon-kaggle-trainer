#!/usr/bin/env python3
from pathlib import Path
import sys, json, re
ROOT=Path(__file__).resolve().parents[1]
errors=[]
required=[
 'project.godot','scenes/main.tscn','scripts/main.gd','scripts/player_controller.gd',
 'scripts/weapon_system.gd','scripts/enemy_ai.gd','scripts/health.gd','scripts/mission_director.gd',
 'scripts/story_director.gd','scripts/archive_terminal.gd','scripts/objective_zone.gd','scripts/hud.gd'
]
for rel in required:
    if not (ROOT/rel).is_file(): errors.append('missing '+rel)
project=(ROOT/'project.godot').read_text() if (ROOT/'project.godot').exists() else ''
for token in ['run/main_scene','GameSession','MissionDirector','StoryDirector']:
    if token not in project: errors.append('project setting missing '+token)
main=(ROOT/'scripts/main.gd').read_text() if (ROOT/'scripts/main.gd').exists() else ''
for token in ['Soldier_Male.obj','Gun_Rifle.obj','Enemy_EyeDrone.obj','Enemy_QuadShell.obj','Enemy_Trilobite.obj','MissionDirector.reset_mission']:
    if token not in main: errors.append('main feature missing '+token)
mission=(ROOT/'scripts/mission_director.gd').read_text() if (ROOT/'scripts/mission_director.gd').exists() else ''
for token in ['INFILTRATE','RETRIEVE_ARCHIVE','SURVIVE_AMBUSH','EXTRACTION','COMPLETE','required_kills']:
    if token not in mission: errors.append('mission token missing '+token)
player=(ROOT/'scripts/player_controller.gd').read_text() if (ROOT/'scripts/player_controller.gd').exists() else ''
for token in ['KEY_W','KEY_SHIFT','KEY_SPACE','KEY_E','move_and_slide','intersect_ray']:
    if token not in player: errors.append('player token missing '+token)
weapon=(ROOT/'scripts/weapon_system.gd').read_text() if (ROOT/'scripts/weapon_system.gd').exists() else ''
for token in ['MOUSE_BUTTON_LEFT','KEY_R','intersect_ray','take_damage']:
    if token not in weapon: errors.append('weapon token missing '+token)
objs=list((ROOT/'assets/external').rglob('*.obj'))
mtls=list((ROOT/'assets/external').rglob('*.mtl'))
if len(objs)<80: errors.append(f'too few external OBJ assets: {len(objs)}')
if len(mtls)<80: errors.append(f'too few external MTL assets: {len(mtls)}')
if not (ROOT/'assets/external/quaternius_characters/OBJ/Soldier_Male.obj').exists(): errors.append('player external model missing')
for n in ['Enemy_EyeDrone.obj','Enemy_QuadShell.obj','Enemy_Trilobite.obj','Gun_Rifle.obj']:
    if not (ROOT/'assets/external/quaternius_scifi/OBJ'/n).exists(): errors.append('external model missing '+n)
# basic delimiter sanity
for gd in (ROOT/'scripts').glob('*.gd'):
    txt=gd.read_text()
    if '\t' in txt: errors.append('tab indentation in '+gd.name)
report={'validation':'failed' if errors else 'passed','gdscript_files':len(list((ROOT/'scripts').glob('*.gd'))),'external_obj_models':len(objs),'external_mtl_files':len(mtls),'errors':errors}
(ROOT/'validation_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(report,indent=2,ensure_ascii=False))
sys.exit(1 if errors else 0)
