class_name ArchiveTerminal
extends Area3D

var prompt: String = "E - Arşivi indir"
var used: bool = false

func can_interact(_player: PlayerController) -> bool:
    return not used and MissionDirector.phase == MissionDirector.MissionPhase.RETRIEVE_ARCHIVE

func interact(player: PlayerController) -> void:
    if not can_interact(player):
        return
    used = true
    MissionDirector.retrieve_archive()
