class_name WeaponSystem
extends Node

@export var damage: float = 34.0
@export var range: float = 90.0
@export var fire_rate: float = 7.0
@export var magazine_size: int = 18
@export var reserve_ammo: int = 90
@export var reload_seconds: float = 1.35

var magazine: int = 18
var reloading: bool = false
var _reload_remaining: float = 0.0
var _next_fire_msec: int = 0
var _reload_was_down: bool = false
var aim_camera: Camera3D
var owner_body: CollisionObject3D

func _ready() -> void:
    magazine = magazine_size
    set_process(true)

func configure(camera: Camera3D, body: CollisionObject3D) -> void:
    aim_camera = camera
    owner_body = body

func _process(delta: float) -> void:
    if not reloading:
        return
    _reload_remaining -= delta
    if _reload_remaining <= 0.0:
        var missing := magazine_size - magazine
        var moved := mini(missing, reserve_ammo)
        magazine += moved
        reserve_ammo -= moved
        reloading = false

func tick_input() -> void:
    if not GameSession.can_play:
        return
    var reload_down := Input.is_key_pressed(KEY_R)
    if reload_down and not _reload_was_down:
        try_reload()
    _reload_was_down = reload_down
    if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        try_fire()

func try_fire() -> void:
    var now := Time.get_ticks_msec()
    if reloading or now < _next_fire_msec:
        return
    if magazine <= 0:
        try_reload()
        return
    if aim_camera == null:
        return
    _next_fire_msec = now + int(1000.0 / fire_rate)
    magazine -= 1

    var origin := aim_camera.global_position
    var target := origin + (-aim_camera.global_transform.basis.z * range)
    var query := PhysicsRayQueryParameters3D.create(origin, target, 1 | 4)
    if owner_body != null:
        query.exclude = [owner_body.get_rid()]
    query.collide_with_areas = false
    var hit := aim_camera.get_world_3d().direct_space_state.intersect_ray(query)
    if hit.is_empty():
        return
    var collider := hit.get("collider") as Node
    if collider == null or collider.is_in_group("player"):
        return
    var health := collider.get_node_or_null("Health") as Health
    if health != null:
        health.take_damage(damage)

func try_reload() -> void:
    if reloading or magazine >= magazine_size or reserve_ammo <= 0:
        return
    reloading = true
    _reload_remaining = reload_seconds
