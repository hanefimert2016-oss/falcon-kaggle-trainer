class_name Health
extends Node

signal died(health: Health)
signal changed(current: float, maximum: float)

@export var max_health: float = 100.0
@export var destroy_on_death: bool = true
var current: float = 100.0
var is_dead: bool = false

func _ready() -> void:
    current = max_health

func take_damage(amount: float) -> void:
    if is_dead or amount <= 0.0:
        return
    current = maxf(0.0, current - amount)
    changed.emit(current, max_health)
    if current <= 0.0:
        _die()

func heal(amount: float) -> void:
    if is_dead or amount <= 0.0:
        return
    current = minf(max_health, current + amount)
    changed.emit(current, max_health)

func _die() -> void:
    if is_dead:
        return
    is_dead = true
    died.emit(self)
    var actor := get_parent()
    if actor != null and actor.is_in_group("player"):
        GameSession.fail_mission("Ajan etkisiz hale getirildi.")
