class_name GameHUD
extends CanvasLayer

var player: PlayerController
var objective_label: Label
var health_label: Label
var ammo_label: Label
var prompt_label: Label
var story_panel: PanelContainer
var story_speaker: Label
var story_line: Label
var end_panel: PanelContainer
var end_label: Label

func _ready() -> void:
    layer = 20
    _build_ui()

func _process(_delta: float) -> void:
    if player == null or not is_instance_valid(player):
        player = get_tree().get_first_node_in_group("player") as PlayerController
    objective_label.text = MissionDirector.objective_text
    if player != null and player.health != null and player.weapon != null:
        health_label.text = "CAN  %d/%d" % [int(ceil(player.health.current)), int(ceil(player.health.max_health))]
        ammo_label.text = "ŞARJÖR  YÜKLENİYOR" if player.weapon.reloading else "MERMİ  %d/%d" % [player.weapon.magazine, player.weapon.reserve_ammo]
        prompt_label.text = player.interaction_prompt
    story_panel.visible = StoryDirector.visible
    story_speaker.text = StoryDirector.speaker
    story_line.text = StoryDirector.line
    end_panel.visible = not GameSession.can_play
    end_label.text = GameSession.end_message

func _label(text: String, size: int = 18) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", Color.WHITE)
    return l

func _panel_at(offset_left: float, offset_top: float, offset_right: float, offset_bottom: float) -> PanelContainer:
    var p := PanelContainer.new()
    p.set_anchors_preset(Control.PRESET_TOP_LEFT)
    p.offset_left = offset_left
    p.offset_top = offset_top
    p.offset_right = offset_right
    p.offset_bottom = offset_bottom
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0.02, 0.04, 0.07, 0.88)
    sb.border_color = Color(0.0, 0.8, 1.0, 0.45)
    sb.set_border_width_all(1)
    sb.corner_radius_top_left = 8
    sb.corner_radius_top_right = 8
    sb.corner_radius_bottom_left = 8
    sb.corner_radius_bottom_right = 8
    p.add_theme_stylebox_override("panel", sb)
    return p

func _build_ui() -> void:
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)

    var mission := _panel_at(20, 20, 500, 116)
    root.add_child(mission)
    var mv := VBoxContainer.new()
    mv.add_theme_constant_override("separation", 4)
    mission.add_child(mv)
    var title := _label("ECHO PROTOCOL: BLACKSITE", 20)
    mv.add_child(title)
    objective_label = _label("Görev yükleniyor...", 16)
    objective_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    mv.add_child(objective_label)

    var status := _panel_at(1030, 20, 1260, 116)
    root.add_child(status)
    var sv := VBoxContainer.new()
    status.add_child(sv)
    health_label = _label("CAN", 16)
    ammo_label = _label("MERMİ", 16)
    sv.add_child(health_label)
    sv.add_child(ammo_label)

    var cross := _label("+", 28)
    cross.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    cross.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    cross.set_anchors_preset(Control.PRESET_CENTER)
    cross.offset_left = -20
    cross.offset_right = 20
    cross.offset_top = -20
    cross.offset_bottom = 20
    root.add_child(cross)

    prompt_label = _label("", 22)
    prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    prompt_label.set_anchors_preset(Control.PRESET_CENTER)
    prompt_label.offset_left = -260
    prompt_label.offset_right = 260
    prompt_label.offset_top = 115
    prompt_label.offset_bottom = 155
    root.add_child(prompt_label)

    story_panel = PanelContainer.new()
    story_panel.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
    story_panel.offset_left = -390
    story_panel.offset_right = 390
    story_panel.offset_top = -145
    story_panel.offset_bottom = -35
    var story_box := StyleBoxFlat.new()
    story_box.bg_color = Color(0.01, 0.02, 0.04, 0.92)
    story_box.border_color = Color(0.0, 0.8, 1.0, 0.5)
    story_box.set_border_width_all(1)
    story_panel.add_theme_stylebox_override("panel", story_box)
    root.add_child(story_panel)
    var story_v := VBoxContainer.new()
    story_panel.add_child(story_v)
    story_speaker = _label("", 18)
    story_line = _label("", 17)
    story_line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    story_v.add_child(story_speaker)
    story_v.add_child(story_line)

    end_panel = PanelContainer.new()
    end_panel.set_anchors_preset(Control.PRESET_CENTER)
    end_panel.offset_left = -320
    end_panel.offset_right = 320
    end_panel.offset_top = -90
    end_panel.offset_bottom = 90
    var end_box := StyleBoxFlat.new()
    end_box.bg_color = Color(0.01, 0.02, 0.04, 0.96)
    end_box.border_color = Color(0.1, 0.9, 0.7, 0.8)
    end_box.set_border_width_all(2)
    end_panel.add_theme_stylebox_override("panel", end_box)
    root.add_child(end_panel)
    end_label = _label("", 26)
    end_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    end_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    end_panel.add_child(end_label)
