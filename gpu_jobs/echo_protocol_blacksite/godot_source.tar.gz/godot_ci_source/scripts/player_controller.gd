class_name PlayerController
extends CharacterBody3D

@export var walk_speed: float = 5.2
@export var sprint_speed: float = 8.2
@export var jump_height: float = 1.4
@export var gravity: float = 24.0
@export var rotation_sharpness: float = 14.0
@export var interaction_distance: float = 3.2

var health: Health
var weapon: WeaponSystem
var view_camera: Camera3D
var interaction_prompt: String = ""
var _jump_was_down: bool = false
var _interact_was_down: bool = false

func _ready() -> void:
    add_to_group("player")
    health = get_node("Health") as Health
    weapon = get_node("WeaponSystem") as WeaponSystem
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func configure(camera: Camera3D) -> void:
    view_camera = camera
    if weapon != null:
        weapon.configure(camera, self)

func _physics_process(delta: float) -> void:
    if health == null or health.is_dead or not GameSession.can_play:
        return
    _move_player(delta)
    _handle_interaction()
    weapon.tick_input()

func _move_player(delta: float) -> void:
    if view_camera == null:
        return
    var input_vec := Vector2.ZERO
    if Input.is_key_pressed(KEY_A): input_vec.x -= 1.0
    if Input.is_key_pressed(KEY_D): input_vec.x += 1.0
    if Input.is_key_pressed(KEY_W): input_vec.y -= 1.0
    if Input.is_key_pressed(KEY_S): input_vec.y += 1.0
    input_vec = input_vec.normalized() if input_vec.length() > 1.0 else input_vec

    var forward := -view_camera.global_transform.basis.z
    var right := view_camera.global_transform.basis.x
    forward.y = 0.0
    right.y = 0.0
    forward = forward.normalized()
    right = right.normalized()
    var move_dir := (right * input_vec.x) + (forward * -input_vec.y)
    var speed := sprint_speed if Input.is_key_pressed(KEY_SHIFT) else walk_speed
    velocity.x = move_dir.x * speed
    velocity.z = move_dir.z * speed

    if is_on_floor() and velocity.y < 0.0:
        velocity.y = -0.5
    var jump_down := Input.is_key_pressed(KEY_SPACE)
    if is_on_floor() and jump_down and not _jump_was_down:
        velocity.y = sqrt(jump_height * 2.0 * gravity)
    _jump_was_down = jump_down
    if not is_on_floor():
        velocity.y -= gravity * delta

    move_and_slide()
    if move_dir.length_squared() > 0.04:
        var target_yaw := atan2(-move_dir.x, -move_dir.z)
        rotation.y = lerp_angle(rotation.y, target_yaw, 1.0 - exp(-rotation_sharpness * delta))

func _handle_interaction() -> void:
    interaction_prompt = ""
    if view_camera == null:
        return
    var origin := view_camera.global_position
    var target := origin + (-view_camera.global_transform.basis.z * interaction_distance)
    var query := PhysicsRayQueryParameters3D.create(origin, target, 8)
    query.exclude = [get_rid()]
    query.collide_with_areas = true
    query.collide_with_bodies = false
    var hit := get_world_3d().direct_space_state.intersect_ray(query)
    var interact_down := Input.is_key_pressed(KEY_E)
    if not hit.is_empty():
        var collider := hit.get("collider") as Node
        if collider != null and collider.has_method("can_interact") and collider.can_interact(self):
            var maybe_prompt = collider.get("prompt")
            interaction_prompt = str(maybe_prompt) if maybe_prompt != null else "E - Etkileş"
            if interact_down and not _interact_was_down:
                collider.interact(self)
    _interact_was_down = interact_down
