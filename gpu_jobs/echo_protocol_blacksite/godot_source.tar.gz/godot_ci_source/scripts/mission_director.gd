extends Node

enum MissionPhase { INFILTRATE, RETRIEVE_ARCHIVE, SURVIVE_AMBUSH, EXTRACTION, COMPLETE }

var phase: int = MissionPhase.INFILTRATE
var kills: int = 0
var required_kills: int = 5
var objective_text: String = ""
var ambush_enemies: Array[Node] = []

func reset_mission(enemies: Array[Node], kills_needed: int = 5) -> void:
    phase = MissionPhase.INFILTRATE
    kills = 0
    required_kills = maxi(1, kills_needed)
    ambush_enemies = enemies
    for enemy in ambush_enemies:
        if is_instance_valid(enemy) and enemy.has_method("set_active"):
            enemy.set_active(false)
    _set_objective("İletişim kulesine sız.")

func begin() -> void:
    StoryDirector.say("ECHO", "Blacksite çevrimdışı görünüyor. İçeri gir ve arşivi bul.", 5.0)

func reach_tower() -> void:
    if phase != MissionPhase.INFILTRATE:
        return
    phase = MissionPhase.RETRIEVE_ARCHIVE
    _set_objective("Şifreli arşiv terminalini bul ve E ile indir.")
    StoryDirector.say("ECHO", "İçeridesin. Terminalin yerini işaretliyorum.", 4.0)

func retrieve_archive() -> void:
    if phase != MissionPhase.RETRIEVE_ARCHIVE:
        return
    phase = MissionPhase.SURVIVE_AMBUSH
    kills = 0
    _set_objective("Pusuyu temizle: %d/%d" % [kills, required_kills])
    for enemy in ambush_enemies:
        if is_instance_valid(enemy) and enemy.has_method("set_active"):
            enemy.set_active(true)
    StoryDirector.say("KONTROL", "Alarm tetiklendi. Temas! Alanı temizle!", 4.0)

func register_enemy_kill() -> void:
    if phase != MissionPhase.SURVIVE_AMBUSH:
        return
    kills += 1
    _set_objective("Pusuyu temizle: %d/%d" % [kills, required_kills])
    if kills < required_kills:
        return
    phase = MissionPhase.EXTRACTION
    _set_objective("Tahliye bölgesine ulaş.")
    StoryDirector.say("ECHO", "Arşiv güvenli. Güney tahliyesine koş.", 4.0)

func reach_extraction() -> void:
    if phase != MissionPhase.EXTRACTION:
        return
    phase = MissionPhase.COMPLETE
    _set_objective("GÖREV TAMAMLANDI")
    StoryDirector.say("KONTROL", "Paket alındı. Blacksite artık kör değil.", 6.0)
    GameSession.complete_mission()

func _set_objective(text: String) -> void:
    objective_text = text
