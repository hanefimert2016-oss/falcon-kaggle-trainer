extends Node

var speaker: String = ""
var line: String = ""
var visible: bool = false
var _serial: int = 0

func reset_story() -> void:
    _serial += 1
    speaker = ""
    line = ""
    visible = false

func say(who: String, text: String, duration: float = 4.0) -> void:
    _serial += 1
    var serial := _serial
    speaker = who
    line = text
    visible = true
    _hide_after(maxf(1.0, duration), serial)

func _hide_after(duration: float, serial: int) -> void:
    await get_tree().create_timer(duration, true, false, true).timeout
    if serial == _serial:
        visible = false
