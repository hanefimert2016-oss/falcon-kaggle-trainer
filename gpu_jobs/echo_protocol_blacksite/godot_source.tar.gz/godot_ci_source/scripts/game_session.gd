extends Node

var can_play: bool = true
var mission_complete: bool = false
var end_message: String = ""

func reset_session() -> void:
    can_play = true
    mission_complete = false
    end_message = ""
    Engine.time_scale = 1.0

func complete_mission() -> void:
    mission_complete = true
    end_message = "ECHO PROTOCOL // GÖREV TAMAMLANDI"
    can_play = false
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func fail_mission(reason: String) -> void:
    mission_complete = false
    end_message = reason
    can_play = false
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
