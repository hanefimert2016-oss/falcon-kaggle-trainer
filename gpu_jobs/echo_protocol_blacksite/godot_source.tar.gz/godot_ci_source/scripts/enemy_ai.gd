class_name EnemyAI
extends CharacterBody3D

@export var move_speed: float = 3.4
@export var detection_range: float = 28.0
@export var attack_range: float = 2.2
@export var attack_damage: float = 16.0
@export var attack_cooldown: float = 1.0
@export var gravity: float = 24.0

var health: Health
var target: PlayerController
var active: bool = false
var _next_attack_msec: int = 0

func _ready() -> void:
    health = get_node("Health") as Health
    health.died.connect(_on_died)
    target = get_tree().get_first_node_in_group("player") as PlayerController

func set_active(value: bool) -> void:
    active = value
    visible = value
    collision_layer = 4 if value else 0
    collision_mask = (1 | 2) if value else 0
    set_physics_process(value)

func _physics_process(delta: float) -> void:
    if not active or health == null or health.is_dead or not GameSession.can_play:
        return
    if target == null or not is_instance_valid(target):
        target = get_tree().get_first_node_in_group("player") as PlayerController
        if target == null:
            return
    var to_target := target.global_position - global_position
    var planar := Vector3(to_target.x, 0.0, to_target.z)
    var distance := planar.length()
    if distance > detection_range:
        velocity.x = move_toward(velocity.x, 0.0, move_speed)
        velocity.z = move_toward(velocity.z, 0.0, move_speed)
    elif distance > attack_range:
        var direction := planar.normalized()
        velocity.x = direction.x * move_speed
        velocity.z = direction.z * move_speed
        var target_yaw := atan2(-direction.x, -direction.z)
        rotation.y = lerp_angle(rotation.y, target_yaw, 1.0 - exp(-10.0 * delta))
    else:
        velocity.x = 0.0
        velocity.z = 0.0
        var now := Time.get_ticks_msec()
        if now >= _next_attack_msec:
            _next_attack_msec = now + int(attack_cooldown * 1000.0)
            if target.health != null:
                target.health.take_damage(attack_damage)
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = -0.5
    move_and_slide()

func _on_died(_health: Health) -> void:
    if not active:
        return
    active = false
    set_physics_process(false)
    collision_layer = 0
    collision_mask = 0
    MissionDirector.register_enemy_kill()
    _fade_and_remove()

func _fade_and_remove() -> void:
    await get_tree().create_timer(1.25).timeout
    if is_instance_valid(self):
        queue_free()
