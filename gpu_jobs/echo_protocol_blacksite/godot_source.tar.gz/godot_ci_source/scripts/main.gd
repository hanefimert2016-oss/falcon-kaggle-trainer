extends Node3D

const PLAYER_MODEL := "res://assets/external/quaternius_characters/OBJ/Soldier_Male.obj"
const RIFLE_MODEL := "res://assets/external/quaternius_scifi/OBJ/Gun_Rifle.obj"
const DRONE_MODELS := [
    "res://assets/external/quaternius_scifi/OBJ/Enemy_EyeDrone.obj",
    "res://assets/external/quaternius_scifi/OBJ/Enemy_QuadShell.obj",
    "res://assets/external/quaternius_scifi/OBJ/Enemy_Trilobite.obj",
]
const PROP_MODELS := [
    "res://assets/external/quaternius_scifi/OBJ/Prop_Crate.obj",
    "res://assets/external/quaternius_scifi/OBJ/Prop_Crate_Large.obj",
    "res://assets/external/quaternius_scifi/OBJ/Prop_Locker.obj",
    "res://assets/external/quaternius_scifi/OBJ/Prop_Barrel1.obj",
]
const TERMINAL_MODEL := "res://assets/external/quaternius_scifi/OBJ/Prop_Desk_Medium.obj"
const TOWER_MODEL := "res://assets/external/quaternius_scifi/OBJ/Prop_SatelliteDish.obj"

func _ready() -> void:
    GameSession.reset_session()
    StoryDirector.reset_story()
    _build_world()
    var player := _build_player(Vector3(0, 1.0, 21))
    var enemies: Array[Node] = []
    var enemy_positions := [
        Vector3(-5.5, 0.9, -4), Vector3(5.5, 0.9, -4), Vector3(-4, 0.9, -14),
        Vector3(4, 0.9, -14), Vector3(0, 0.9, -21)
    ]
    for i in range(enemy_positions.size()):
        enemies.append(_build_enemy(enemy_positions[i], i))
    _build_tower_zone(Vector3(0, 0.5, 8))
    _build_terminal(Vector3(0, 0.0, -10))
    _build_extraction(Vector3(0, 0.5, 24))
    _place_props()
    var hud := GameHUD.new()
    add_child(hud)
    MissionDirector.reset_mission(enemies, 5)
    MissionDirector.begin()
    player.global_position = Vector3(0, 1.0, 21)

func _build_world() -> void:
    var environment := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.01, 0.015, 0.03)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.18, 0.24, 0.34)
    env.ambient_light_energy = 0.8
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_light_color = Color(0.04, 0.08, 0.13)
    env.fog_density = 0.012
    environment.environment = env
    add_child(environment)

    var light := DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-58, -28, 0)
    light.light_color = Color(0.68, 0.8, 1.0)
    light.light_energy = 1.25
    light.shadow_enabled = true
    add_child(light)

    _box_body("Floor", Vector3(0, -0.5, 0), Vector3(24, 1, 64), Color(0.045, 0.06, 0.075))
    _box_body("WallLeft", Vector3(-12.5, 2.5, 0), Vector3(1, 6, 64), Color(0.055, 0.07, 0.085))
    _box_body("WallRight", Vector3(12.5, 2.5, 0), Vector3(1, 6, 64), Color(0.055, 0.07, 0.085))
    _box_body("WallNorth", Vector3(0, 2.5, -32), Vector3(24, 6, 1), Color(0.055, 0.07, 0.085))
    _box_body("WallSouth", Vector3(0, 2.5, 32), Vector3(24, 6, 1), Color(0.055, 0.07, 0.085))
    # Interior cover / corridor geometry.
    _box_body("CoverA", Vector3(-5.5, 1.0, 2), Vector3(5, 2, 1), Color(0.08, 0.1, 0.12))
    _box_body("CoverB", Vector3(5.5, 1.0, -7), Vector3(5, 2, 1), Color(0.08, 0.1, 0.12))
    _box_body("CoverC", Vector3(-5.5, 1.0, -17), Vector3(5, 2, 1), Color(0.08, 0.1, 0.12))

func _build_player(pos: Vector3) -> PlayerController:
    var player := PlayerController.new()
    player.name = "ECHO7"
    player.position = pos
    player.collision_layer = 2
    player.collision_mask = 1 | 4

    var shape := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.42
    capsule.height = 1.8
    shape.shape = capsule
    player.add_child(shape)

    var health := Health.new()
    health.name = "Health"
    health.max_health = 100.0
    health.destroy_on_death = false
    player.add_child(health)

    var weapon := WeaponSystem.new()
    weapon.name = "WeaponSystem"
    player.add_child(weapon)

    var visual := _mesh_visual(PLAYER_MODEL, Color(0.14, 0.22, 0.12), 0.85)
    visual.name = "External_Soldier_Male"
    visual.rotation_degrees.y = 180.0
    player.add_child(visual)

    var rifle := _mesh_visual(RIFLE_MODEL, Color(0.1, 0.14, 0.18), 0.55)
    rifle.name = "External_Gun_Rifle"
    rifle.position = Vector3(0.38, 1.08, -0.34)
    rifle.rotation_degrees = Vector3(0, 180, -6)
    player.add_child(rifle)

    var pivot := CameraController.new()
    pivot.name = "CameraPivot"
    pivot.position = Vector3(0, 1.58, 0)
    player.add_child(pivot)
    var arm := SpringArm3D.new()
    arm.spring_length = 5.2
    arm.margin = 0.18
    arm.collision_mask = 1
    pivot.add_child(arm)
    var camera := Camera3D.new()
    camera.current = true
    arm.add_child(camera)

    # Add only after all required children exist so _ready() resolves them safely.
    add_child(player)
    player.configure(camera)
    return player

func _build_enemy(pos: Vector3, index: int) -> EnemyAI:
    var enemy := EnemyAI.new()
    enemy.name = "SecurityUnit_%02d" % index
    enemy.position = pos
    var shape := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.55
    capsule.height = 1.5
    shape.shape = capsule
    enemy.add_child(shape)
    var health := Health.new()
    health.name = "Health"
    health.max_health = 68.0
    health.destroy_on_death = true
    enemy.add_child(health)
    var model_path: String = DRONE_MODELS[index % DRONE_MODELS.size()]
    var visual := _mesh_visual(model_path, Color(0.68, 0.13, 0.12), 0.9)
    visual.position.y = -0.35
    visual.rotation_degrees.y = 180.0
    enemy.add_child(visual)
    add_child(enemy)
    enemy.set_active(false)
    return enemy

func _build_tower_zone(pos: Vector3) -> void:
    var zone := ObjectiveZone.new()
    zone.name = "InfiltrationZone"
    zone.zone_type = ObjectiveZone.ZoneType.TOWER
    zone.position = pos
    zone.collision_layer = 8
    zone.collision_mask = 2
    add_child(zone)
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(8, 3, 5)
    shape.shape = box
    zone.add_child(shape)
    var tower := _mesh_visual(TOWER_MODEL, Color(0.12, 0.32, 0.38), 1.35)
    tower.position = Vector3(4.5, -0.5, -0.5)
    zone.add_child(tower)

func _build_terminal(pos: Vector3) -> void:
    var terminal := ArchiveTerminal.new()
    terminal.name = "ArchiveTerminal"
    terminal.position = pos
    terminal.collision_layer = 8
    terminal.collision_mask = 0
    add_child(terminal)
    var shape := CollisionShape3D.new()
    var box := BoxShape3D.new()
    box.size = Vector3(2.8, 2.0, 1.8)
    shape.shape = box
    shape.position.y = 0.9
    terminal.add_child(shape)
    var desk := _mesh_visual(TERMINAL_MODEL, Color(0.08, 0.23, 0.32), 1.15)
    terminal.add_child(desk)
    var marker := OmniLight3D.new()
    marker.position = Vector3(0, 1.65, 0)
    marker.light_color = Color(0.0, 0.9, 1.0)
    marker.light_energy = 2.2
    marker.omni_range = 5.0
    terminal.add_child(marker)

func _build_extraction(pos: Vector3) -> void:
    var zone := ObjectiveZone.new()
    zone.name = "ExtractionZone"
    zone.zone_type = ObjectiveZone.ZoneType.EXTRACTION
    zone.position = pos
    zone.collision_layer = 8
    zone.collision_mask = 2
    add_child(zone)
    var shape := CollisionShape3D.new()
    var cylinder := CylinderShape3D.new()
    cylinder.radius = 3.2
    cylinder.height = 2.0
    shape.shape = cylinder
    zone.add_child(shape)
    var ring := MeshInstance3D.new()
    var mesh := CylinderMesh.new()
    mesh.top_radius = 3.2
    mesh.bottom_radius = 3.2
    mesh.height = 0.05
    ring.mesh = mesh
    ring.position.y = -0.42
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.05, 0.85, 0.45, 0.55)
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.emission_enabled = true
    mat.emission = Color(0.0, 0.8, 0.35)
    mat.emission_energy_multiplier = 1.7
    ring.material_override = mat
    zone.add_child(ring)

func _place_props() -> void:
    var positions := [
        Vector3(-8, 0, 14), Vector3(8, 0, 12), Vector3(-7, 0, 0), Vector3(7, 0, -1),
        Vector3(-8, 0, -10), Vector3(8, 0, -13), Vector3(-7, 0, -23), Vector3(7, 0, -24)
    ]
    for i in range(positions.size()):
        var prop := _mesh_visual(PROP_MODELS[i % PROP_MODELS.size()], Color(0.16, 0.2, 0.23), 1.0)
        prop.position = positions[i]
        prop.rotation_degrees.y = float((i * 47) % 360)
        add_child(prop)

func _mesh_visual(path: String, color: Color, scale_value: float) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var resource := load(path)
    if resource is Mesh:
        mi.mesh = resource as Mesh
    else:
        push_error("External model could not be loaded: " + path)
    mi.scale = Vector3.ONE * scale_value
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.metallic = 0.18
    mat.roughness = 0.62
    mi.material_override = mat
    return mi

func _box_body(name_text: String, pos: Vector3, size: Vector3, color: Color) -> StaticBody3D:
    var body := StaticBody3D.new()
    body.name = name_text
    body.position = pos
    body.collision_layer = 1
    body.collision_mask = 2 | 4
    add_child(body)
    var shape := CollisionShape3D.new()
    var box_shape := BoxShape3D.new()
    box_shape.size = size
    shape.shape = box_shape
    body.add_child(shape)
    var visual := MeshInstance3D.new()
    var box_mesh := BoxMesh.new()
    box_mesh.size = size
    visual.mesh = box_mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.metallic = 0.25
    mat.roughness = 0.74
    visual.material_override = mat
    body.add_child(visual)
    return body
