class_name CameraController
extends Node3D

@export var mouse_sensitivity: float = 0.0026
@export var min_pitch: float = -35.0
@export var max_pitch: float = 70.0
var yaw: float = 0.0
var pitch: float = deg_to_rad(-12.0)

func _ready() -> void:
    Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and GameSession.can_play:
        yaw -= event.relative.x * mouse_sensitivity
        pitch -= event.relative.y * mouse_sensitivity
        pitch = clampf(pitch, deg_to_rad(min_pitch), deg_to_rad(max_pitch))
        rotation = Vector3(pitch, yaw, 0.0)
    elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_RIGHT:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
