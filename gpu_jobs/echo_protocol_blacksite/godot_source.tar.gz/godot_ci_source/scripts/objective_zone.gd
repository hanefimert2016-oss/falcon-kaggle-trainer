class_name ObjectiveZone
extends Area3D

enum ZoneType { TOWER, EXTRACTION }
@export_enum("Tower", "Extraction") var zone_type: int = ZoneType.TOWER
var used: bool = false

func _ready() -> void:
    body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node3D) -> void:
    if used or not body.is_in_group("player"):
        return
    if zone_type == ZoneType.TOWER:
        MissionDirector.reach_tower()
        used = true
    elif zone_type == ZoneType.EXTRACTION and MissionDirector.phase == MissionDirector.MissionPhase.EXTRACTION:
        MissionDirector.reach_extraction()
        used = true
